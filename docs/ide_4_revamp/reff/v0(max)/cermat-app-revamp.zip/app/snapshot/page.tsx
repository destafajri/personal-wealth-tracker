"use client";

import { useState, useCallback, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { SnapshotHeader } from "@/components/snapshot/snapshot-header";
import { SummarySidebar } from "@/components/snapshot/summary-sidebar";
import { FinancialForm } from "@/components/snapshot/financial-form";

function SnapshotContent() {
  const searchParams = useSearchParams();
  const isDemo = searchParams.get("demo") === "true";
  
  const [summaryData, setSummaryData] = useState({
    penghasilan: isDemo ? 19000000 : 0,
    pengeluaran: isDemo ? 10000000 : 0,
    totalAset: isDemo ? 810000000 : 0,
    kekayaanBersih: isDemo ? 445000000 : 0,
  });

  const handleDataChange = useCallback((data: typeof summaryData) => {
    setSummaryData(data);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-gray-50">
      <SnapshotHeader />
      
      <main className="mx-auto max-w-7xl px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sticky Sidebar - Summary Dashboard */}
          <div className="lg:order-1 order-2">
            <SummarySidebar data={summaryData} />
          </div>
          
          {/* Scrollable Form */}
          <div className="lg:order-2 order-1 flex-1">
            <FinancialForm isDemo={isDemo} onDataChange={handleDataChange} />
          </div>
        </div>
      </main>
    </div>
  );
}

export default function SnapshotPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-gradient-to-b from-white to-gray-50 flex items-center justify-center">
        <div className="animate-pulse text-slate-500">Memuat...</div>
      </div>
    }>
      <SnapshotContent />
    </Suspense>
  );
}
