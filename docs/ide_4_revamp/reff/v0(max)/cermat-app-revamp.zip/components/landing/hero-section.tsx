"use client";

import { Lock, CloudOff, FileText, Play, ChevronRight, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export function HeroSection() {
  return (
    <section className="pt-32 pb-24 px-4">
      <div className="mx-auto max-w-4xl text-center">
        {/* Headline */}
        <h1 className="text-4xl sm:text-5xl font-bold text-slate-900 leading-tight text-balance">
          Aman gak kalau gw KPR, Gadai, atau Cicil?
        </h1>
        
        {/* Sub-headline */}
        <p className="mt-4 text-lg text-slate-600 max-w-2xl mx-auto text-pretty">
          Berapa max utang yang aman? Cek keuangan kamu dalam 10 menit.
        </p>
        
        {/* Trust Badges */}
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-100">
            <Lock className="w-4 h-4" />
            <span className="text-sm font-medium">Tanpa daftar</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-100">
            <CloudOff className="w-4 h-4" />
            <span className="text-sm font-medium">Tanpa cloud</span>
          </div>
        </div>
        
        {/* Action Cards */}
        <div className="mt-12 grid sm:grid-cols-2 gap-6 max-w-3xl mx-auto">
          {/* Primary Card */}
          <div className="group relative bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-all overflow-hidden">
            <div className="h-1 bg-emerald-500" />
            <div className="p-6">
              <div className="w-12 h-12 rounded-xl bg-emerald-100 flex items-center justify-center mb-4">
                <FileText className="w-6 h-6 text-emerald-600" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 text-left">
                Mulai dari Snapshot
              </h3>
              <p className="mt-2 text-slate-600 text-left text-sm">
                Isi data kamu sendiri (5–10 menit).
              </p>
              <Button asChild className="w-full mt-6 bg-emerald-600 hover:bg-emerald-700 text-white">
                <Link href="/snapshot">
                  Mulai
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Link>
              </Button>
            </div>
          </div>
          
          {/* Secondary Card */}
          <div className="group relative bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-all overflow-hidden">
            <div className="h-1 bg-gray-200" />
            <div className="p-6">
              <div className="w-12 h-12 rounded-xl bg-gray-100 flex items-center justify-center mb-4">
                <Play className="w-6 h-6 text-gray-600" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 text-left">
                Coba dengan data contoh
              </h3>
              <p className="mt-2 text-slate-600 text-left text-sm">
                Skip dulu, lihat tools-nya.
              </p>
              <Button asChild variant="outline" className="w-full mt-6 bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100 hover:text-emerald-800">
                <Link href="/snapshot?demo=true">
                  Coba
                  <ArrowRight className="w-4 h-4 ml-1" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
