"use client";

import { Shield, Clock } from "lucide-react";

export function Navbar() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border/50 bg-white/80 backdrop-blur-sm">
      <div className="mx-auto max-w-6xl px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-emerald-100">
            <Shield className="w-5 h-5 text-emerald-600" />
          </div>
          <span className="text-xl font-bold text-slate-900">Cermat</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-slate-500">
          <Clock className="w-4 h-4" />
          <span className="hidden sm:inline">Cek Keuangan dalam 10 Menit</span>
          <span className="sm:hidden">10 Menit</span>
        </div>
      </div>
    </nav>
  );
}
