"use client";

import { Lock } from "lucide-react";

export function Footer() {
  return (
    <footer className="py-8 px-4 border-t border-border/50">
      <div className="mx-auto max-w-4xl flex flex-col items-center gap-2 text-center">
        <div className="flex items-center gap-2 text-sm text-slate-500">
          <Lock className="w-3.5 h-3.5" />
          <span>
            <span className="font-medium text-slate-700">Cermat.</span> Data diproses secara lokal di browser Anda untuk privasi maksimal.
          </span>
        </div>
      </div>
    </footer>
  );
}
