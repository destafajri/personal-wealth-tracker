"use client";

import { useState, useEffect } from "react";
import { 
  Banknote, 
  ShoppingCart, 
  PiggyBank, 
  TrendingUp, 
  Home, 
  CreditCard,
  FileText,
  ChevronLeft,
  ChevronRight,
  Lock
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { CurrencyInput, SectionTotal, SectionSuccess } from "./currency-input";

interface FinancialData {
  // Penghasilan
  gajiPokok: number;
  pendapatanSampingan: number;
  pendapatanLainnya: number;
  // Pengeluaran
  kebutuhanPokok: number;
  transportasi: number;
  tagihan: number;
  hiburan: number;
  pengeluaranLainnya: number;
  // Tabungan
  tabunganDarurat: number;
  tabunganRutin: number;
  // Investasi
  saham: number;
  reksadana: number;
  deposito: number;
  kripto: number;
  // Aset
  nilaiRumah: number;
  nilaiKendaraan: number;
  asetLainnya: number;
  // Utang
  kpr: number;
  kendaraan: number;
  kartuKredit: number;
  pinjamanLainnya: number;
}

const defaultData: FinancialData = {
  gajiPokok: 0,
  pendapatanSampingan: 0,
  pendapatanLainnya: 0,
  kebutuhanPokok: 0,
  transportasi: 0,
  tagihan: 0,
  hiburan: 0,
  pengeluaranLainnya: 0,
  tabunganDarurat: 0,
  tabunganRutin: 0,
  saham: 0,
  reksadana: 0,
  deposito: 0,
  kripto: 0,
  nilaiRumah: 0,
  nilaiKendaraan: 0,
  asetLainnya: 0,
  kpr: 0,
  kendaraan: 0,
  kartuKredit: 0,
  pinjamanLainnya: 0,
};

const demoData: FinancialData = {
  gajiPokok: 15000000,
  pendapatanSampingan: 3000000,
  pendapatanLainnya: 1000000,
  kebutuhanPokok: 5000000,
  transportasi: 1500000,
  tagihan: 2000000,
  hiburan: 1000000,
  pengeluaranLainnya: 500000,
  tabunganDarurat: 50000000,
  tabunganRutin: 10000000,
  saham: 30000000,
  reksadana: 20000000,
  deposito: 25000000,
  kripto: 5000000,
  nilaiRumah: 500000000,
  nilaiKendaraan: 150000000,
  asetLainnya: 20000000,
  kpr: 300000000,
  kendaraan: 50000000,
  kartuKredit: 5000000,
  pinjamanLainnya: 10000000,
};

interface FinancialFormProps {
  isDemo: boolean;
  onDataChange: (data: {
    penghasilan: number;
    pengeluaran: number;
    totalAset: number;
    kekayaanBersih: number;
  }) => void;
}

const sections = [
  { id: "penghasilan", label: "Penghasilan", icon: Banknote },
  { id: "pengeluaran", label: "Pengeluaran", icon: ShoppingCart },
  { id: "tabungan", label: "Tabungan", icon: PiggyBank },
  { id: "investasi", label: "Investasi", icon: TrendingUp },
  { id: "aset", label: "Aset", icon: Home },
  { id: "utang", label: "Utang", icon: CreditCard },
  { id: "ringkasan", label: "Ringkasan", icon: FileText },
];

export function FinancialForm({ isDemo, onDataChange }: FinancialFormProps) {
  const [data, setData] = useState<FinancialData>(isDemo ? demoData : defaultData);
  const [activeSection, setActiveSection] = useState(0);

  const updateField = (field: keyof FinancialData, value: number) => {
    setData((prev) => ({ ...prev, [field]: value }));
  };

  // Calculate totals
  const totalPenghasilan = data.gajiPokok + data.pendapatanSampingan + data.pendapatanLainnya;
  const totalPengeluaran = data.kebutuhanPokok + data.transportasi + data.tagihan + data.hiburan + data.pengeluaranLainnya;
  const totalTabungan = data.tabunganDarurat + data.tabunganRutin;
  const totalInvestasi = data.saham + data.reksadana + data.deposito + data.kripto;
  const totalAset = data.nilaiRumah + data.nilaiKendaraan + data.asetLainnya + totalTabungan + totalInvestasi;
  const totalUtang = data.kpr + data.kendaraan + data.kartuKredit + data.pinjamanLainnya;
  const kekayaanBersih = totalAset - totalUtang;

  useEffect(() => {
    onDataChange({
      penghasilan: totalPenghasilan,
      pengeluaran: totalPengeluaran,
      totalAset,
      kekayaanBersih,
    });
  }, [totalPenghasilan, totalPengeluaran, totalAset, kekayaanBersih, onDataChange]);

  const goToSection = (index: number) => {
    setActiveSection(Math.max(0, Math.min(sections.length - 1, index)));
  };

  return (
    <div className="flex-1 min-w-0">
      {/* Progress Timeline */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 mb-6">
        <div className="flex items-center justify-between overflow-x-auto gap-1">
          {sections.map((section, index) => {
            const Icon = section.icon;
            const isActive = index === activeSection;
            const isCompleted = index < activeSection;
            
            return (
              <button
                key={section.id}
                onClick={() => goToSection(index)}
                className={`flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition-all min-w-fit ${
                  isActive
                    ? "bg-emerald-100 text-emerald-700"
                    : isCompleted
                    ? "bg-emerald-50 text-emerald-600"
                    : "text-slate-400 hover:bg-slate-50"
                }`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  isActive
                    ? "bg-emerald-600 text-white"
                    : isCompleted
                    ? "bg-emerald-500 text-white"
                    : "bg-slate-200 text-slate-500"
                }`}>
                  <Icon className="w-4 h-4" />
                </div>
                <span className="text-xs font-medium whitespace-nowrap">{section.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Form Sections */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm">
        {/* Section 0: Penghasilan */}
        {activeSection === 0 && (
          <div className="p-6">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-slate-900">Penghasilan Bulanan</h2>
              <p className="text-slate-600 mt-1">Masukkan semua sumber pendapatan Anda per bulan</p>
            </div>
            
            <div className="space-y-6">
              <CurrencyInput
                id="gajiPokok"
                label="Gaji Pokok"
                description="Gaji utama dari pekerjaan"
                tooltip="Gaji bersih setelah pajak yang Anda terima setiap bulan"
                value={data.gajiPokok}
                onChange={(v) => updateField("gajiPokok", v)}
                placeholder="Rp 15.000.000"
              />
              <CurrencyInput
                id="pendapatanSampingan"
                label="Pendapatan Sampingan"
                description="Freelance, bisnis sampingan"
                tooltip="Penghasilan dari pekerjaan sampingan atau bisnis"
                value={data.pendapatanSampingan}
                onChange={(v) => updateField("pendapatanSampingan", v)}
                placeholder="Rp 3.000.000"
              />
              <CurrencyInput
                id="pendapatanLainnya"
                label="Pendapatan Lainnya"
                description="Dividen, sewa, dll"
                tooltip="Passive income seperti dividen saham, sewa properti"
                value={data.pendapatanLainnya}
                onChange={(v) => updateField("pendapatanLainnya", v)}
                placeholder="Rp 1.000.000"
              />
            </div>
            
            <div className="mt-6">
              <SectionTotal label="Total Penghasilan Bulanan" value={totalPenghasilan} />
            </div>
            
            {totalPenghasilan > 0 && (
              <SectionSuccess message="Bagus! Anda telah menginput penghasilan Anda. Lanjut ke pengeluaran rutin." />
            )}
          </div>
        )}

        {/* Section 1: Pengeluaran */}
        {activeSection === 1 && (
          <div className="p-6">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-slate-900">Pengeluaran Bulanan</h2>
              <p className="text-slate-600 mt-1">Berapa total pengeluaran rutin Anda setiap bulan?</p>
            </div>
            
            <div className="space-y-6">
              <CurrencyInput
                id="kebutuhanPokok"
                label="Kebutuhan Pokok"
                description="Makanan, pakaian, kebutuhan rumah tangga"
                value={data.kebutuhanPokok}
                onChange={(v) => updateField("kebutuhanPokok", v)}
                placeholder="Rp 5.000.000"
              />
              <CurrencyInput
                id="transportasi"
                label="Transportasi"
                description="Bensin, parkir, transportasi umum"
                value={data.transportasi}
                onChange={(v) => updateField("transportasi", v)}
                placeholder="Rp 1.500.000"
              />
              <CurrencyInput
                id="tagihan"
                label="Tagihan & Utilitas"
                description="Listrik, air, internet, telepon"
                value={data.tagihan}
                onChange={(v) => updateField("tagihan", v)}
                placeholder="Rp 2.000.000"
              />
              <CurrencyInput
                id="hiburan"
                label="Hiburan & Lifestyle"
                description="Makan di luar, streaming, hobi"
                value={data.hiburan}
                onChange={(v) => updateField("hiburan", v)}
                placeholder="Rp 1.000.000"
              />
              <CurrencyInput
                id="pengeluaranLainnya"
                label="Pengeluaran Lainnya"
                description="Pengeluaran tidak terduga"
                value={data.pengeluaranLainnya}
                onChange={(v) => updateField("pengeluaranLainnya", v)}
                placeholder="Rp 500.000"
              />
            </div>
            
            <div className="mt-6">
              <SectionTotal label="Total Pengeluaran Bulanan" value={totalPengeluaran} />
            </div>
          </div>
        )}

        {/* Section 2: Tabungan */}
        {activeSection === 2 && (
          <div className="p-6">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-slate-900">Tabungan</h2>
              <p className="text-slate-600 mt-1">Berapa total tabungan yang Anda miliki saat ini?</p>
            </div>
            
            <div className="space-y-6">
              <CurrencyInput
                id="tabunganDarurat"
                label="Dana Darurat"
                description="Tabungan untuk keadaan darurat"
                tooltip="Idealnya 3-6x pengeluaran bulanan"
                value={data.tabunganDarurat}
                onChange={(v) => updateField("tabunganDarurat", v)}
                placeholder="Rp 50.000.000"
              />
              <CurrencyInput
                id="tabunganRutin"
                label="Tabungan Rutin"
                description="Tabungan biasa di bank"
                value={data.tabunganRutin}
                onChange={(v) => updateField("tabunganRutin", v)}
                placeholder="Rp 10.000.000"
              />
            </div>
            
            <div className="mt-6">
              <SectionTotal label="Total Tabungan" value={totalTabungan} />
            </div>
          </div>
        )}

        {/* Section 3: Investasi */}
        {activeSection === 3 && (
          <div className="p-6">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-slate-900">Investasi</h2>
              <p className="text-slate-600 mt-1">Berapa nilai total portofolio investasi Anda?</p>
            </div>
            
            <div className="space-y-6">
              <CurrencyInput
                id="saham"
                label="Saham"
                description="Nilai portofolio saham saat ini"
                value={data.saham}
                onChange={(v) => updateField("saham", v)}
                placeholder="Rp 30.000.000"
              />
              <CurrencyInput
                id="reksadana"
                label="Reksadana"
                description="Nilai unit reksadana saat ini"
                value={data.reksadana}
                onChange={(v) => updateField("reksadana", v)}
                placeholder="Rp 20.000.000"
              />
              <CurrencyInput
                id="deposito"
                label="Deposito"
                description="Total deposito berjangka"
                value={data.deposito}
                onChange={(v) => updateField("deposito", v)}
                placeholder="Rp 25.000.000"
              />
              <CurrencyInput
                id="kripto"
                label="Cryptocurrency"
                description="Nilai aset kripto saat ini"
                value={data.kripto}
                onChange={(v) => updateField("kripto", v)}
                placeholder="Rp 5.000.000"
              />
            </div>
            
            <div className="mt-6">
              <SectionTotal label="Total Investasi" value={totalInvestasi} />
            </div>
          </div>
        )}

        {/* Section 4: Aset */}
        {activeSection === 4 && (
          <div className="p-6">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-slate-900">Aset Tetap</h2>
              <p className="text-slate-600 mt-1">Berapa estimasi nilai aset tetap Anda?</p>
            </div>
            
            <div className="space-y-6">
              <CurrencyInput
                id="nilaiRumah"
                label="Properti / Rumah"
                description="Estimasi nilai pasar rumah/apartemen"
                value={data.nilaiRumah}
                onChange={(v) => updateField("nilaiRumah", v)}
                placeholder="Rp 500.000.000"
              />
              <CurrencyInput
                id="nilaiKendaraan"
                label="Kendaraan"
                description="Mobil, motor, dll"
                value={data.nilaiKendaraan}
                onChange={(v) => updateField("nilaiKendaraan", v)}
                placeholder="Rp 150.000.000"
              />
              <CurrencyInput
                id="asetLainnya"
                label="Aset Lainnya"
                description="Perhiasan, barang koleksi, dll"
                value={data.asetLainnya}
                onChange={(v) => updateField("asetLainnya", v)}
                placeholder="Rp 20.000.000"
              />
            </div>
            
            <div className="mt-6">
              <SectionTotal label="Total Aset Tetap" value={data.nilaiRumah + data.nilaiKendaraan + data.asetLainnya} />
            </div>
          </div>
        )}

        {/* Section 5: Utang */}
        {activeSection === 5 && (
          <div className="p-6">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-slate-900">Utang & Cicilan</h2>
              <p className="text-slate-600 mt-1">Berapa total sisa utang yang harus dilunasi?</p>
            </div>
            
            <div className="space-y-6">
              <CurrencyInput
                id="kpr"
                label="KPR / Cicilan Rumah"
                description="Sisa pokok KPR"
                value={data.kpr}
                onChange={(v) => updateField("kpr", v)}
                placeholder="Rp 300.000.000"
              />
              <CurrencyInput
                id="kendaraan"
                label="Cicilan Kendaraan"
                description="Sisa cicilan mobil/motor"
                value={data.kendaraan}
                onChange={(v) => updateField("kendaraan", v)}
                placeholder="Rp 50.000.000"
              />
              <CurrencyInput
                id="kartuKredit"
                label="Kartu Kredit"
                description="Total tagihan kartu kredit"
                value={data.kartuKredit}
                onChange={(v) => updateField("kartuKredit", v)}
                placeholder="Rp 5.000.000"
              />
              <CurrencyInput
                id="pinjamanLainnya"
                label="Pinjaman Lainnya"
                description="Pinjaman online, KTA, dll"
                value={data.pinjamanLainnya}
                onChange={(v) => updateField("pinjamanLainnya", v)}
                placeholder="Rp 10.000.000"
              />
            </div>
            
            <div className="mt-6">
              <SectionTotal label="Total Utang" value={totalUtang} />
            </div>
          </div>
        )}

        {/* Section 6: Ringkasan */}
        {activeSection === 6 && (
          <div className="p-6">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-slate-900">Ringkasan Keuangan</h2>
              <p className="text-slate-600 mt-1">Berikut adalah gambaran lengkap kondisi keuangan Anda</p>
            </div>
            
            <div className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="bg-emerald-50 rounded-xl p-4 border border-emerald-100">
                  <p className="text-sm text-emerald-600 font-medium">Penghasilan Bulanan</p>
                  <p className="text-xl font-bold text-emerald-700 mt-1">+{new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(totalPenghasilan)}</p>
                </div>
                <div className="bg-red-50 rounded-xl p-4 border border-red-100">
                  <p className="text-sm text-red-600 font-medium">Pengeluaran Bulanan</p>
                  <p className="text-xl font-bold text-red-700 mt-1">-{new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(totalPengeluaran)}</p>
                </div>
              </div>
              
              <div className="bg-blue-50 rounded-xl p-4 border border-blue-100">
                <p className="text-sm text-blue-600 font-medium">Surplus Bulanan</p>
                <p className="text-2xl font-bold text-blue-700 mt-1">{new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(totalPenghasilan - totalPengeluaran)}</p>
              </div>
              
              <div className="border-t border-gray-100 pt-4 mt-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="bg-slate-50 rounded-xl p-4 border border-slate-100">
                    <p className="text-sm text-slate-600 font-medium">Total Aset</p>
                    <p className="text-xl font-bold text-slate-700 mt-1">{new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(totalAset)}</p>
                  </div>
                  <div className="bg-slate-50 rounded-xl p-4 border border-slate-100">
                    <p className="text-sm text-slate-600 font-medium">Total Utang</p>
                    <p className="text-xl font-bold text-slate-700 mt-1">{new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(totalUtang)}</p>
                  </div>
                </div>
              </div>
              
              <div className={`rounded-xl p-5 border ${kekayaanBersih >= 0 ? "bg-emerald-50 border-emerald-200" : "bg-red-50 border-red-200"}`}>
                <p className={`text-sm font-medium ${kekayaanBersih >= 0 ? "text-emerald-600" : "text-red-600"}`}>Kekayaan Bersih (Net Worth)</p>
                <p className={`text-3xl font-bold mt-1 ${kekayaanBersih >= 0 ? "text-emerald-700" : "text-red-700"}`}>
                  {new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(kekayaanBersih)}
                </p>
                <p className={`text-sm mt-2 ${kekayaanBersih >= 0 ? "text-emerald-600" : "text-red-600"}`}>
                  {kekayaanBersih >= 0 
                    ? "Selamat! Kondisi keuangan Anda dalam keadaan sehat." 
                    : "Perhatian! Utang Anda melebihi total aset."}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Navigation Buttons */}
        <div className="px-6 pb-6 pt-2 border-t border-gray-100">
          <div className="flex items-center justify-between">
            <Button
              variant="outline"
              onClick={() => goToSection(activeSection - 1)}
              disabled={activeSection === 0}
              className="gap-1"
            >
              <ChevronLeft className="w-4 h-4" />
              Sebelumnya
            </Button>
            <Button
              onClick={() => goToSection(activeSection + 1)}
              disabled={activeSection === sections.length - 1}
              className="gap-1 bg-emerald-600 hover:bg-emerald-700 text-white"
            >
              Simpan & Lanjutkan
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
          
          <div className="mt-4 flex items-center justify-center gap-2 text-xs text-slate-500">
            <Lock className="w-3 h-3" />
            <span>Privasi Anda terjaga. Data disimpan lokal di browser Anda, tidak dikirim ke server.</span>
          </div>
        </div>
      </div>
    </div>
  );
}
