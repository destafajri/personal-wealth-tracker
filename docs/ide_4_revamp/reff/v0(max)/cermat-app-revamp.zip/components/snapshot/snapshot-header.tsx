"use client";

import { Shield } from "lucide-react";

export function SnapshotHeader() {
  return (
    <header className="sticky top-0 z-50 border-b border-border/50 bg-white/95 backdrop-blur-sm">
      <div className="mx-auto max-w-7xl px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-emerald-100">
              <Shield className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <span className="text-lg font-bold text-emerald-600">Cermat</span>
              <p className="text-xs text-slate-500 -mt-0.5">Kalkulator Keuangan</p>
            </div>
          </div>
        </div>
        <div className="px-3 py-1.5 rounded-full bg-slate-100 text-slate-600 text-sm font-medium">
          Gratis - Tanpa Login
        </div>
      </div>
    </header>
  );
}
