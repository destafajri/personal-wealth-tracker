"use client";

import { ArrowUp, ArrowDown, LineChart, BarChart3, Wallet } from "lucide-react";
import { formatRupiah } from "@/lib/format";

interface SummaryData {
  penghasilan: number;
  pengeluaran: number;
  totalAset: number;
  kekayaanBersih: number;
}

interface SummarySidebarProps {
  data: SummaryData;
}

export function SummarySidebar({ data }: SummarySidebarProps) {
  const surplus = data.penghasilan - data.pengeluaran;

  return (
    <aside className="w-full lg:w-80 lg:sticky lg:top-20 lg:h-fit">
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
        <h2 className="text-lg font-bold text-slate-900 mb-4">Ringkasan Cepat</h2>
        
        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3">
          {/* Penghasilan */}
          <div className="bg-emerald-50 rounded-xl p-3">
            <div className="flex items-center gap-1.5 text-emerald-600 mb-1">
              <ArrowUp className="w-4 h-4" />
              <span className="text-xs font-medium">Penghasilan</span>
            </div>
            <p className="text-sm font-bold text-emerald-700">
              {formatRupiah(data.penghasilan)}
            </p>
          </div>
          
          {/* Pengeluaran */}
          <div className="bg-red-50 rounded-xl p-3">
            <div className="flex items-center gap-1.5 text-red-600 mb-1">
              <ArrowDown className="w-4 h-4" />
              <span className="text-xs font-medium">Pengeluaran</span>
            </div>
            <p className="text-sm font-bold text-red-700">
              {formatRupiah(data.pengeluaran)}
            </p>
          </div>
          
          {/* Total Aset */}
          <div className="bg-blue-50 rounded-xl p-3">
            <div className="flex items-center gap-1.5 text-blue-600 mb-1">
              <LineChart className="w-4 h-4" />
              <span className="text-xs font-medium">Total Aset</span>
            </div>
            <p className="text-sm font-bold text-blue-700">
              {formatRupiah(data.totalAset)}
            </p>
          </div>
          
          {/* Kekayaan Bersih */}
          <div className="bg-emerald-50 rounded-xl p-3">
            <div className="flex items-center gap-1.5 text-emerald-600 mb-1">
              <BarChart3 className="w-4 h-4" />
              <span className="text-xs font-medium">Kekayaan Bersih</span>
            </div>
            <p className="text-sm font-bold text-emerald-700">
              {formatRupiah(data.kekayaanBersih)}
            </p>
          </div>
        </div>
        
        {/* Surplus Card */}
        <div className="mt-4 bg-emerald-50 rounded-xl p-4 border border-emerald-100">
          <div className="flex items-center gap-2 text-emerald-700 mb-1">
            <Wallet className="w-5 h-5" />
            <span className="text-sm font-medium">Surplus Bulanan</span>
          </div>
          <p className="text-2xl font-bold text-emerald-700">
            {surplus >= 0 ? "+" : ""}{formatRupiah(surplus)}
          </p>
        </div>
      </div>
    </aside>
  );
}
