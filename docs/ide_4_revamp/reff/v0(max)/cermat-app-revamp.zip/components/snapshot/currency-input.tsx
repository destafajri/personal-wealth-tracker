"use client";

import { Info, Check, Wallet } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { formatRupiah } from "@/lib/format";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface CurrencyInputProps {
  id: string;
  label: string;
  description: string;
  tooltip?: string;
  value: number;
  onChange: (value: number) => void;
  placeholder?: string;
}

export function CurrencyInput({
  id,
  label,
  description,
  tooltip,
  value,
  onChange,
  placeholder = "Rp 0",
}: CurrencyInputProps) {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawValue = e.target.value.replace(/[^\d]/g, "");
    onChange(parseInt(rawValue, 10) || 0);
  };

  const displayValue = value > 0 ? formatRupiah(value) : "";

  return (
    <div className="group">
      <div className="flex items-center gap-2 mb-1.5">
        <Label htmlFor={id} className="text-sm font-medium text-slate-700">
          {label}
        </Label>
        {tooltip && (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Info className="w-3.5 h-3.5 text-slate-400 cursor-help" />
              </TooltipTrigger>
              <TooltipContent>
                <p className="max-w-xs text-sm">{tooltip}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}
      </div>
      <Input
        id={id}
        type="text"
        inputMode="numeric"
        value={displayValue}
        onChange={handleChange}
        placeholder={placeholder}
        className="h-12 text-base border-gray-200 focus:border-emerald-500 focus:ring-emerald-500"
      />
      <p className="mt-1 text-xs text-slate-500">{description}</p>
    </div>
  );
}

interface SectionTotalProps {
  label: string;
  value: number;
}

export function SectionTotal({ label, value }: SectionTotalProps) {
  return (
    <div className="flex items-center justify-between bg-emerald-50 rounded-xl p-4 border border-emerald-100">
      <div className="flex items-center gap-2 text-emerald-700">
        <Wallet className="w-5 h-5" />
        <span className="font-medium">{label}</span>
      </div>
      <span className="text-lg font-bold text-emerald-700">
        {formatRupiah(value)}
      </span>
    </div>
  );
}

interface SectionSuccessProps {
  message: string;
}

export function SectionSuccess({ message }: SectionSuccessProps) {
  return (
    <div className="flex items-center gap-2 text-emerald-600 mt-4">
      <div className="w-5 h-5 rounded-full bg-emerald-100 flex items-center justify-center">
        <Check className="w-3 h-3" />
      </div>
      <span className="text-sm">{message}</span>
    </div>
  );
}
