export interface FinancialData {
  // Penghasilan
  gajiPokok: string;
  pendapatanSampingan: string;
  pendapatanLainnya: string;
  // Pengeluaran
  kebutuhanPokok: string;
  transportasi: string;
  utilitas: string;
  hiburan: string;
  pendidikan: string;
  pengeluaranLainnya: string;
  // Tabungan
  tabunganDarurat: string;
  tabunganTujuan: string;
  // Investasi
  saham: string;
  reksa: string;
  obligasi: string;
  investasiLainnya: string;
  // Aset
  nilaiRumah: string;
  nilaiKendaraan: string;
  asetLainnya: string;
  // Utang
  kprBulanan: string;
  kprSisa: string;
  kendaraanBulanan: string;
  kendaraanSisa: string;
  kartuKredit: string;
  utangLainnya: string;
}

export const INITIAL_DATA: FinancialData = {
  gajiPokok: '',
  pendapatanSampingan: '',
  pendapatanLainnya: '',
  kebutuhanPokok: '',
  transportasi: '',
  utilitas: '',
  hiburan: '',
  pendidikan: '',
  pengeluaranLainnya: '',
  tabunganDarurat: '',
  tabunganTujuan: '',
  saham: '',
  reksa: '',
  obligasi: '',
  investasiLainnya: '',
  nilaiRumah: '',
  nilaiKendaraan: '',
  asetLainnya: '',
  kprBulanan: '',
  kprSisa: '',
  kendaraanBulanan: '',
  kendaraanSisa: '',
  kartuKredit: '',
  utangLainnya: '',
};

export const DEMO_DATA: FinancialData = {
  gajiPokok: '15000000',
  pendapatanSampingan: '3000000',
  pendapatanLainnya: '500000',
  kebutuhanPokok: '4000000',
  transportasi: '1500000',
  utilitas: '800000',
  hiburan: '1000000',
  pendidikan: '500000',
  pengeluaranLainnya: '200000',
  tabunganDarurat: '500000',
  tabunganTujuan: '1000000',
  saham: '500000',
  reksa: '500000',
  obligasi: '200000',
  investasiLainnya: '0',
  nilaiRumah: '500000000',
  nilaiKendaraan: '150000000',
  asetLainnya: '20000000',
  kprBulanan: '3500000',
  kprSisa: '350000000',
  kendaraanBulanan: '1500000',
  kendaraanSisa: '80000000',
  kartuKredit: '2000000',
  utangLainnya: '0',
};

export function parseNum(val: string): number {
  const cleaned = val.replace(/[^\d]/g, '');
  return cleaned ? parseInt(cleaned, 10) : 0;
}

export function formatRupiah(num: number): string {
  if (num === 0) return 'Rp 0';
  return 'Rp ' + num.toLocaleString('id-ID');
}

export function formatInput(val: string): string {
  const num = parseNum(val);
  if (!num) return '';
  return num.toLocaleString('id-ID');
}

export function calcSummary(data: FinancialData) {
  const penghasilan = parseNum(data.gajiPokok) + parseNum(data.pendapatanSampingan) + parseNum(data.pendapatanLainnya);
  const pengeluaran =
    parseNum(data.kebutuhanPokok) +
    parseNum(data.transportasi) +
    parseNum(data.utilitas) +
    parseNum(data.hiburan) +
    parseNum(data.pendidikan) +
    parseNum(data.pengeluaranLainnya) +
    parseNum(data.tabunganDarurat) +
    parseNum(data.tabunganTujuan);
  const cicilan =
    parseNum(data.kprBulanan) + parseNum(data.kendaraanBulanan) + parseNum(data.kartuKredit) + parseNum(data.utangLainnya);
  const totalAset =
    parseNum(data.nilaiRumah) +
    parseNum(data.nilaiKendaraan) +
    parseNum(data.asetLainnya) +
    parseNum(data.saham) +
    parseNum(data.reksa) +
    parseNum(data.obligasi) +
    parseNum(data.investasiLainnya);
  const totalUtang = parseNum(data.kprSisa) + parseNum(data.kendaraanSisa) + parseNum(data.kartuKredit) * 12 + parseNum(data.utangLainnya);
  const kekayaanBersih = totalAset - totalUtang;
  const totalPengeluaran = pengeluaran + cicilan;
  const surplus = penghasilan - totalPengeluaran;
  const dsr = penghasilan > 0 ? (cicilan / penghasilan) * 100 : 0;

  return { penghasilan, totalPengeluaran, totalAset, kekayaanBersih, surplus, dsr, cicilan };
}
