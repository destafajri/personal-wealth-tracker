import { useState } from 'react';
import './App.css';
import LandingPage from './pages/LandingPage';
import SnapshotPage from './pages/SnapshotPage';
import { DEMO_DATA, INITIAL_DATA, FinancialData } from './lib/finance';

type Page = 'landing' | 'snapshot';

export default function App() {
  const [page, setPage] = useState<Page>('landing');
  const [snapshotData, setSnapshotData] = useState<FinancialData>(INITIAL_DATA);

  if (page === 'snapshot') {
    return (
      <SnapshotPage
        onBack={() => setPage('landing')}
        initialData={snapshotData}
      />
    );
  }

  return (
    <LandingPage
      onStart={() => {
        setSnapshotData(INITIAL_DATA);
        setPage('snapshot');
      }}
      onDemo={() => {
        setSnapshotData(DEMO_DATA);
        setPage('snapshot');
      }}
    />
  );
}
