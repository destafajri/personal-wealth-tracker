import { useState, useCallback } from 'react';
import {
  ShieldCheck, ChevronLeft, ChevronRight, CheckCircle2, Wallet, TrendingUp,
  PiggyBank, BarChart2, Home, CreditCard, ClipboardList, Lock, Menu, X
} from 'lucide-react';
import { FinancialData, INITIAL_DATA, calcSummary, formatRupiah, parseNum } from '../lib/finance';
import SnapshotSidebar from '../components/SnapshotSidebar';
import CurrencyInput from '../components/CurrencyInput';

interface SnapshotPageProps {
  onBack: () => void;
  initialData?: FinancialData;
}

const SECTIONS = [
  { id: 'penghasilan', label: 'Penghasilan', icon: TrendingUp },
  { id: 'pengeluaran', label: 'Pengeluaran', icon: Wallet },
  { id: 'tabungan', label: 'Tabungan', icon: PiggyBank },
  { id: 'investasi', label: 'Investasi', icon: BarChart2 },
  { id: 'aset', label: 'Aset', icon: Home },
  { id: 'utang', label: 'Utang', icon: CreditCard },
  { id: 'ringkasan', label: 'Ringkasan', icon: ClipboardList },
];

export default function SnapshotPage({ onBack, initialData }: SnapshotPageProps) {
  const [data, setData] = useState<FinancialData>(initialData ?? INITIAL_DATA);
  const [activeSection, setActiveSection] = useState(0);
  const [completedSections, setCompletedSections] = useState<Set<number>>(new Set());
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const set = useCallback((key: keyof FinancialData) => (val: string) => {
    setData((prev) => ({ ...prev, [key]: val }));
  }, []);

  const goNext = () => {
    setCompletedSections((prev) => new Set([...prev, activeSection]));
    setActiveSection((s) => Math.min(s + 1, SECTIONS.length - 1));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const goPrev = () => {
    setActiveSection((s) => Math.max(s - 1, 0));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const summary = calcSummary(data);

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-sm border-b border-gray-100 px-4 sm:px-6 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={onBack}
              className="mr-1 p-1.5 rounded-lg hover:bg-gray-100 transition-colors text-slate-500 hover:text-slate-700"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <div className="w-7 h-7 bg-emerald-600 rounded-lg flex items-center justify-center">
              <ShieldCheck className="w-3.5 h-3.5 text-white" strokeWidth={2.5} />
            </div>
            <div>
              <div className="text-base font-bold text-emerald-600 leading-none">Cermat</div>
              <div className="text-xs text-slate-400 leading-none mt-0.5">Kalkulator Keuangan</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="hidden sm:inline-flex items-center gap-1.5 bg-gray-100 text-slate-500 text-xs font-medium px-3 py-1.5 rounded-full">
              <Lock className="w-3 h-3" /> Gratis · Tanpa Login
            </span>
            <button
              className="lg:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              {sidebarOpen ? <X className="w-5 h-5 text-slate-600" /> : <Menu className="w-5 h-5 text-slate-600" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Sidebar Drawer */}
      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-40 flex">
          <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
          <div className="relative ml-auto w-80 max-w-full bg-white h-full overflow-y-auto p-5 shadow-xl">
            <SnapshotSidebar data={data} />
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        <div className="flex gap-6">
          {/* Sticky Left Sidebar */}
          <aside className="hidden lg:block w-72 shrink-0">
            <div className="sticky top-24">
              <SnapshotSidebar data={data} />
            </div>
          </aside>

          {/* Main Content */}
          <main className="flex-1 min-w-0">
            {/* Section Nav Pills */}
            <div className="flex gap-1.5 flex-wrap mb-6 bg-gray-50 p-1.5 rounded-2xl border border-gray-100">
              {SECTIONS.map((s, idx) => {
                const Icon = s.icon;
                const isActive = idx === activeSection;
                const isDone = completedSections.has(idx);
                return (
                  <button
                    key={s.id}
                    onClick={() => setActiveSection(idx)}
                    className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 ${
                      isActive
                        ? 'bg-white text-emerald-700 shadow-sm border border-emerald-100'
                        : isDone
                        ? 'text-emerald-600 hover:bg-white/60'
                        : 'text-slate-400 hover:text-slate-600 hover:bg-white/40'
                    }`}
                  >
                    {isDone && !isActive ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                    ) : (
                      <Icon className="w-3.5 h-3.5" />
                    )}
                    <span className="hidden sm:inline">{s.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Section Content */}
            <div className="space-y-4">
              {activeSection === 0 && (
                <PenghasilanSection data={data} set={set} completed={completedSections.has(0)} />
              )}
              {activeSection === 1 && (
                <PengeluaranSection data={data} set={set} completed={completedSections.has(1)} />
              )}
              {activeSection === 2 && (
                <TabunganSection data={data} set={set} completed={completedSections.has(2)} />
              )}
              {activeSection === 3 && (
                <InvestasiSection data={data} set={set} completed={completedSections.has(3)} />
              )}
              {activeSection === 4 && (
                <AsetSection data={data} set={set} completed={completedSections.has(4)} />
              )}
              {activeSection === 5 && (
                <UtangSection data={data} set={set} completed={completedSections.has(5)} />
              )}
              {activeSection === 6 && (
                <RingkasanSection data={data} summary={summary} />
              )}
            </div>

            {/* Bottom Action Bar */}
            {activeSection < 6 && (
              <div className="mt-6 space-y-3">
                <div className="flex gap-3">
                  {activeSection > 0 && (
                    <button
                      onClick={goPrev}
                      className="flex items-center gap-2 px-5 py-3 border border-gray-200 text-slate-600 font-semibold rounded-xl hover:bg-gray-50 transition-all text-sm"
                    >
                      <ChevronLeft className="w-4 h-4" /> Sebelumnya
                    </button>
                  )}
                  <button
                    onClick={goNext}
                    className="flex-1 flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-3 px-6 rounded-xl transition-all shadow-sm hover:shadow-emerald-200 hover:shadow-md text-sm"
                  >
                    {activeSection === 5 ? 'Lihat Ringkasan' : 'Simpan & Lanjutkan'}
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
                <p className="flex items-center justify-center gap-1.5 text-xs text-slate-400">
                  <Lock className="w-3 h-3" />
                  Privasi Anda terjaga. Data disimpan lokal di browser Anda, tidak dikirim ke server.
                </p>
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
}

/* ─── Section Components ─────────────────────────────── */

function SectionHeader({ title, subtitle, icon: Icon }: { title: string; subtitle: string; icon: React.ElementType }) {
  return (
    <div className="flex items-start gap-3 mb-5">
      <div className="w-10 h-10 bg-emerald-50 rounded-xl flex items-center justify-center shrink-0">
        <Icon className="w-5 h-5 text-emerald-600" />
      </div>
      <div>
        <h2 className="text-xl font-bold text-slate-900">{title}</h2>
        <p className="text-sm text-slate-500 mt-0.5">{subtitle}</p>
      </div>
    </div>
  );
}

function SectionCard({ children }: { children: React.ReactNode }) {
  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
      {children}
    </div>
  );
}

function SubtotalBar({ label, value, positive = true }: { label: string; value: string; positive?: boolean }) {
  return (
    <div className={`rounded-xl p-4 flex items-center justify-between mt-4 ${positive ? 'bg-emerald-50 border border-emerald-100' : 'bg-red-50 border border-red-100'}`}>
      <div className="flex items-center gap-2">
        <Wallet className={`w-4 h-4 ${positive ? 'text-emerald-600' : 'text-red-500'}`} />
        <span className="text-sm font-semibold text-slate-700">{label}</span>
      </div>
      <span className={`text-base font-bold ${positive ? 'text-emerald-700' : 'text-red-600'}`}>{value}</span>
    </div>
  );
}

function SuccessNote({ msg }: { msg: string }) {
  return (
    <div className="flex items-center gap-2 mt-4 text-emerald-700 text-sm font-medium">
      <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
      {msg}
    </div>
  );
}

function PenghasilanSection({ data, set, completed }: { data: FinancialData; set: (k: keyof FinancialData) => (v: string) => void; completed: boolean }) {
  const total = parseNum(data.gajiPokok) + parseNum(data.pendapatanSampingan) + parseNum(data.pendapatanLainnya);
  return (
    <SectionCard>
      <SectionHeader title="Penghasilan Bulanan" subtitle="Masukkan semua sumber pendapatan Anda per bulan" icon={TrendingUp} />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <CurrencyInput label="Gaji Pokok" sublabel="Gaji utama dari pekerjaan" tooltip="Gaji bersih (take-home pay) setelah pajak dan potongan" value={data.gajiPokok} placeholder="Rp 15.000.000" onChange={set('gajiPokok')} />
        <CurrencyInput label="Pendapatan Sampingan" sublabel="Freelance, bisnis sampingan" tooltip="Rata-rata pendapatan per bulan dari pekerjaan sampingan" value={data.pendapatanSampingan} placeholder="Rp 3.000.000" onChange={set('pendapatanSampingan')} />
        <CurrencyInput label="Pendapatan Lainnya" sublabel="Dividen, sewa, dll" tooltip="Pendapatan pasif seperti dividen saham, uang sewa, dll" value={data.pendapatanLainnya} placeholder="Rp 1.000.000" onChange={set('pendapatanLainnya')} />
      </div>
      <SubtotalBar label="Total Penghasilan Bulanan" value={formatRupiah(total)} />
      {(completed || total > 0) && <SuccessNote msg="Bagus! Anda telah menginput penghasilan Anda. Lanjut ke pengeluaran rutin." />}
    </SectionCard>
  );
}

function PengeluaranSection({ data, set, completed }: { data: FinancialData; set: (k: keyof FinancialData) => (v: string) => void; completed: boolean }) {
  const total = parseNum(data.kebutuhanPokok) + parseNum(data.transportasi) + parseNum(data.utilitas) + parseNum(data.hiburan) + parseNum(data.pendidikan) + parseNum(data.pengeluaranLainnya);
  return (
    <SectionCard>
      <SectionHeader title="Pengeluaran Rutin" subtitle="Biaya hidup bulanan tanpa cicilan utang" icon={Wallet} />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <CurrencyInput label="Kebutuhan Pokok" sublabel="Makan, belanja, dll" tooltip="Termasuk kebutuhan dapur, makan, dan kebutuhan rumah tangga" value={data.kebutuhanPokok} placeholder="Rp 4.000.000" onChange={set('kebutuhanPokok')} />
        <CurrencyInput label="Transportasi" sublabel="BBM, ojek, angkutan" tooltip="Biaya bensin, ojek online, angkutan umum, dll" value={data.transportasi} placeholder="Rp 1.500.000" onChange={set('transportasi')} />
        <CurrencyInput label="Utilitas" sublabel="Listrik, air, internet" tooltip="Tagihan listrik, air, gas, internet, dan telefon" value={data.utilitas} placeholder="Rp 800.000" onChange={set('utilitas')} />
        <CurrencyInput label="Hiburan & Lifestyle" sublabel="Nongkrong, streaming, dll" tooltip="Langganan streaming, makan di luar, hiburan, dll" value={data.hiburan} placeholder="Rp 1.000.000" onChange={set('hiburan')} />
        <CurrencyInput label="Pendidikan" sublabel="Kursus, sekolah anak" tooltip="Biaya sekolah, kursus, buku, atau pelatihan" value={data.pendidikan} placeholder="Rp 500.000" onChange={set('pendidikan')} />
        <CurrencyInput label="Pengeluaran Lainnya" sublabel="Kesehatan, asuransi, dll" tooltip="Premi asuransi, biaya kesehatan, donasi, dll" value={data.pengeluaranLainnya} placeholder="Rp 500.000" onChange={set('pengeluaranLainnya')} />
      </div>
      <SubtotalBar label="Total Pengeluaran Rutin" value={formatRupiah(total)} positive={false} />
      {(completed || total > 0) && <SuccessNote msg="Data pengeluaran tersimpan. Lanjut ke tabungan bulanan Anda." />}
    </SectionCard>
  );
}

function TabunganSection({ data, set, completed }: { data: FinancialData; set: (k: keyof FinancialData) => (v: string) => void; completed: boolean }) {
  const total = parseNum(data.tabunganDarurat) + parseNum(data.tabunganTujuan);
  return (
    <SectionCard>
      <SectionHeader title="Tabungan Bulanan" subtitle="Berapa yang Anda sisihkan untuk tabungan setiap bulan" icon={PiggyBank} />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <CurrencyInput label="Dana Darurat" sublabel="Simpanan untuk keadaan darurat" tooltip="Idealnya 3-6x pengeluaran bulanan. Masukkan jumlah yang Anda sisihkan per bulan." value={data.tabunganDarurat} placeholder="Rp 500.000" onChange={set('tabunganDarurat')} />
        <CurrencyInput label="Tabungan Tujuan" sublabel="DP rumah, liburan, nikah, dll" tooltip="Tabungan khusus untuk tujuan tertentu seperti DP rumah, pernikahan, dll" value={data.tabunganTujuan} placeholder="Rp 1.000.000" onChange={set('tabunganTujuan')} />
      </div>
      <SubtotalBar label="Total Tabungan per Bulan" value={formatRupiah(total)} />
      {(completed || total > 0) && <SuccessNote msg="Mantap! Anda aktif menabung. Lanjut ke data investasi." />}
    </SectionCard>
  );
}

function InvestasiSection({ data, set, completed }: { data: FinancialData; set: (k: keyof FinancialData) => (v: string) => void; completed: boolean }) {
  const total = parseNum(data.saham) + parseNum(data.reksa) + parseNum(data.obligasi) + parseNum(data.investasiLainnya);
  return (
    <SectionCard>
      <SectionHeader title="Investasi Bulanan" subtitle="Jumlah yang Anda investasikan setiap bulan" icon={BarChart2} />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <CurrencyInput label="Saham" sublabel="Pembelian saham per bulan" tooltip="Jumlah rutin yang diinvestasikan di pasar saham per bulan" value={data.saham} placeholder="Rp 500.000" onChange={set('saham')} />
        <CurrencyInput label="Reksa Dana" sublabel="Reksa dana campuran, pasar uang" tooltip="Investasi reksa dana secara rutin per bulan" value={data.reksa} placeholder="Rp 500.000" onChange={set('reksa')} />
        <CurrencyInput label="Obligasi / SBN" sublabel="Surat utang negara, dll" tooltip="Termasuk ORI, SBR, Sukuk Ritel, atau obligasi korporasi" value={data.obligasi} placeholder="Rp 200.000" onChange={set('obligasi')} />
        <CurrencyInput label="Investasi Lainnya" sublabel="Kripto, P2P, emas, dll" tooltip="Aset investasi lainnya seperti emas, kripto, P2P lending" value={data.investasiLainnya} placeholder="Rp 0" onChange={set('investasiLainnya')} />
      </div>
      <SubtotalBar label="Total Investasi per Bulan" value={formatRupiah(total)} />
      {(completed || total > 0) && <SuccessNote msg="Investasi tercatat. Sekarang isi data aset yang Anda miliki." />}
    </SectionCard>
  );
}

function AsetSection({ data, set, completed }: { data: FinancialData; set: (k: keyof FinancialData) => (v: string) => void; completed: boolean }) {
  const total = parseNum(data.nilaiRumah) + parseNum(data.nilaiKendaraan) + parseNum(data.asetLainnya);
  return (
    <SectionCard>
      <SectionHeader title="Aset Yang Dimiliki" subtitle="Nilai aset fisik dan properti yang Anda miliki saat ini" icon={Home} />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <CurrencyInput label="Nilai Properti" sublabel="Rumah, apartemen, tanah" tooltip="Estimasi nilai pasar properti yang Anda miliki saat ini" value={data.nilaiRumah} placeholder="Rp 500.000.000" onChange={set('nilaiRumah')} />
        <CurrencyInput label="Nilai Kendaraan" sublabel="Mobil, motor" tooltip="Estimasi nilai jual kendaraan Anda saat ini" value={data.nilaiKendaraan} placeholder="Rp 150.000.000" onChange={set('nilaiKendaraan')} />
        <CurrencyInput label="Aset Lainnya" sublabel="Perhiasan, elektronik, dll" tooltip="Aset berharga lainnya yang memiliki nilai jual" value={data.asetLainnya} placeholder="Rp 20.000.000" onChange={set('asetLainnya')} />
      </div>
      <SubtotalBar label="Total Aset Fisik" value={formatRupiah(total)} />
      {(completed || total > 0) && <SuccessNote msg="Data aset tercatat. Terakhir, isi data utang Anda." />}
    </SectionCard>
  );
}

function UtangSection({ data, set, completed }: { data: FinancialData; set: (k: keyof FinancialData) => (v: string) => void; completed: boolean }) {
  const totalCicilan = parseNum(data.kprBulanan) + parseNum(data.kendaraanBulanan) + parseNum(data.kartuKredit) + parseNum(data.utangLainnya);
  return (
    <SectionCard>
      <SectionHeader title="Utang & Cicilan" subtitle="Data utang dan cicilan bulanan Anda saat ini" icon={CreditCard} />
      <div className="mb-4">
        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">Cicilan Bulanan</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <CurrencyInput label="Cicilan KPR" sublabel="Angsuran KPR per bulan" tooltip="Angsuran KPR rumah/apartemen per bulan" value={data.kprBulanan} placeholder="Rp 3.500.000" onChange={set('kprBulanan')} />
          <CurrencyInput label="Cicilan Kendaraan" sublabel="Angsuran kredit kendaraan" tooltip="Angsuran kredit mobil atau motor per bulan" value={data.kendaraanBulanan} placeholder="Rp 1.500.000" onChange={set('kendaraanBulanan')} />
          <CurrencyInput label="Kartu Kredit" sublabel="Tagihan kartu kredit bulanan" tooltip="Total tagihan minimum atau tagihan penuh kartu kredit per bulan" value={data.kartuKredit} placeholder="Rp 2.000.000" onChange={set('kartuKredit')} />
          <CurrencyInput label="Cicilan Lainnya" sublabel="KTA, pinjol, dll" tooltip="Pinjaman tanpa agunan, pinjaman online, dll" value={data.utangLainnya} placeholder="Rp 0" onChange={set('utangLainnya')} />
        </div>
      </div>
      <div className="border-t border-gray-100 pt-4">
        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">Sisa Pokok Utang</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <CurrencyInput label="Sisa KPR" sublabel="Total outstanding KPR" tooltip="Total sisa pokok pinjaman KPR yang belum lunas" value={data.kprSisa} placeholder="Rp 350.000.000" onChange={set('kprSisa')} />
          <CurrencyInput label="Sisa Kredit Kendaraan" sublabel="Total outstanding kredit kendaraan" tooltip="Total sisa pokok kredit kendaraan yang belum lunas" value={data.kendaraanSisa} placeholder="Rp 80.000.000" onChange={set('kendaraanSisa')} />
        </div>
      </div>
      <SubtotalBar label="Total Cicilan per Bulan" value={formatRupiah(totalCicilan)} positive={false} />
      {(completed || totalCicilan > 0) && <SuccessNote msg="Data utang tercatat. Lihat ringkasan keuangan Anda!" />}
    </SectionCard>
  );
}

function RingkasanSection({ data, summary }: { data: FinancialData; summary: ReturnType<typeof calcSummary> }) {
  const { penghasilan, totalPengeluaran, totalAset, kekayaanBersih, surplus, dsr, cicilan } = summary;
  const tabunganInvestasi = parseNum(data.tabunganDarurat) + parseNum(data.tabunganTujuan) + parseNum(data.saham) + parseNum(data.reksa) + parseNum(data.obligasi) + parseNum(data.investasiLainnya);
  const savingsRate = penghasilan > 0 ? (tabunganInvestasi / penghasilan) * 100 : 0;
  const maxKprBulanan = penghasilan * 0.3 - cicilan + parseNum(data.kprBulanan);
  const maxKprBulananSafe = Math.max(0, penghasilan * 0.3 - (cicilan - parseNum(data.kprBulanan)));

  return (
    <div className="space-y-4">
      {/* Hero Summary */}
      <div className={`rounded-2xl p-6 border ${surplus >= 0 ? 'bg-gradient-to-br from-emerald-50 to-white border-emerald-100' : 'bg-gradient-to-br from-red-50 to-white border-red-100'}`}>
        <div className="flex items-center gap-2 mb-1">
          <ClipboardList className="w-5 h-5 text-emerald-600" />
          <h2 className="text-xl font-bold text-slate-900">Ringkasan Keuangan</h2>
        </div>
        <p className="text-sm text-slate-500 mb-5">Berdasarkan data yang Anda masukkan</p>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: 'Penghasilan', val: formatRupiah(penghasilan), color: 'text-emerald-700' },
            { label: 'Pengeluaran', val: formatRupiah(totalPengeluaran), color: 'text-red-600' },
            { label: 'Total Aset', val: formatRupiah(totalAset), color: 'text-blue-700' },
            { label: 'Kekayaan Bersih', val: formatRupiah(kekayaanBersih), color: kekayaanBersih >= 0 ? 'text-emerald-700' : 'text-red-600' },
          ].map((item) => (
            <div key={item.label} className="bg-white rounded-xl p-3 border border-gray-100 shadow-sm">
              <div className="text-xs text-slate-500 mb-1">{item.label}</div>
              <div className={`text-sm font-bold ${item.color} break-all`}>{item.val}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Surplus */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">Surplus Bulanan</div>
          <div className={`text-2xl font-extrabold ${surplus >= 0 ? 'text-emerald-600' : 'text-red-500'} mb-1`}>
            {surplus >= 0 ? '+' : ''}{formatRupiah(surplus)}
          </div>
          <p className="text-xs text-slate-400">{surplus >= 0 ? 'Kondisi keuangan sehat' : 'Kurangi pengeluaran segera'}</p>
        </div>

        {/* DSR */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">Debt Service Ratio</div>
          <div className={`text-2xl font-extrabold mb-1 ${dsr <= 30 ? 'text-emerald-600' : dsr <= 40 ? 'text-amber-500' : 'text-red-500'}`}>
            {dsr.toFixed(1)}%
          </div>
          <div className="w-full bg-gray-100 rounded-full h-1.5 mb-1">
            <div className={`h-1.5 rounded-full ${dsr <= 30 ? 'bg-emerald-500' : dsr <= 40 ? 'bg-amber-400' : 'bg-red-500'}`} style={{ width: `${Math.min(dsr, 100)}%` }} />
          </div>
          <p className="text-xs text-slate-400">{dsr <= 30 ? 'Aman untuk pinjaman baru' : dsr <= 40 ? 'Batas aman, hati-hati' : 'Terlalu berat, jangan tambah utang'}</p>
        </div>

        {/* Savings Rate */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">Savings Rate</div>
          <div className={`text-2xl font-extrabold mb-1 ${savingsRate >= 20 ? 'text-emerald-600' : savingsRate >= 10 ? 'text-amber-500' : 'text-red-500'}`}>
            {savingsRate.toFixed(1)}%
          </div>
          <div className="w-full bg-gray-100 rounded-full h-1.5 mb-1">
            <div className={`h-1.5 rounded-full ${savingsRate >= 20 ? 'bg-emerald-500' : savingsRate >= 10 ? 'bg-amber-400' : 'bg-red-500'}`} style={{ width: `${Math.min(savingsRate, 100)}%` }} />
          </div>
          <p className="text-xs text-slate-400">{savingsRate >= 20 ? 'Ideal (≥ 20%)' : savingsRate >= 10 ? 'Cukup, bisa ditingkatkan' : 'Di bawah ideal, tingkatkan tabungan'}</p>
        </div>
      </div>

      {/* KPR Readiness */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
        <h3 className="font-bold text-slate-800 mb-1">Kapasitas KPR / Cicilan Baru</h3>
        <p className="text-xs text-slate-500 mb-4">Berdasarkan aturan DSR maksimum 30% dari penghasilan</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className={`rounded-xl p-4 border ${maxKprBulananSafe > 0 ? 'bg-emerald-50 border-emerald-100' : 'bg-red-50 border-red-100'}`}>
            <div className="text-xs text-slate-500 mb-1">Max Cicilan Baru per Bulan</div>
            <div className={`text-xl font-extrabold ${maxKprBulananSafe > 0 ? 'text-emerald-700' : 'text-red-600'}`}>
              {formatRupiah(maxKprBulananSafe)}
            </div>
            <p className="text-xs text-slate-500 mt-1">
              {maxKprBulananSafe > 0 ? 'Ruang untuk tambah cicilan' : 'DSR sudah terlalu tinggi'}
            </p>
          </div>
          <div className="rounded-xl p-4 bg-blue-50 border border-blue-100">
            <div className="text-xs text-slate-500 mb-1">Estimasi Max KPR (15 thn, 10%)</div>
            <div className="text-xl font-extrabold text-blue-700">
              {formatRupiah(Math.round(maxKprBulananSafe * 94))}
            </div>
            <p className="text-xs text-slate-500 mt-1">Nilai properti yang aman diambil KPR</p>
          </div>
        </div>
      </div>

      {/* Advice */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
        <h3 className="font-bold text-slate-800 mb-3">Rekomendasi Cermat</h3>
        <div className="space-y-2.5">
          {surplus < 0 && (
            <div className="flex gap-2.5 p-3 bg-red-50 rounded-xl border border-red-100">
              <span className="text-red-500 text-base shrink-0">!</span>
              <p className="text-sm text-red-700">Pengeluaran melebihi penghasilan. Identifikasi dan pangkas pengeluaran yang tidak esensial segera.</p>
            </div>
          )}
          {dsr > 40 && (
            <div className="flex gap-2.5 p-3 bg-red-50 rounded-xl border border-red-100">
              <span className="text-red-500 text-base shrink-0">!</span>
              <p className="text-sm text-red-700">DSR Anda {dsr.toFixed(1)}%. Jangan tambah utang baru. Fokus melunasi utang yang ada terlebih dahulu.</p>
            </div>
          )}
          {dsr > 30 && dsr <= 40 && (
            <div className="flex gap-2.5 p-3 bg-amber-50 rounded-xl border border-amber-100">
              <span className="text-amber-500 text-base shrink-0">~</span>
              <p className="text-sm text-amber-700">DSR Anda {dsr.toFixed(1)}% mendekati batas aman. Pertimbangkan dengan matang sebelum mengambil pinjaman baru.</p>
            </div>
          )}
          {surplus > 0 && dsr <= 30 && (
            <div className="flex gap-2.5 p-3 bg-emerald-50 rounded-xl border border-emerald-100">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
              <p className="text-sm text-emerald-700">Keuangan Anda dalam kondisi sehat! Surplus bulanan bisa dioptimalkan untuk investasi atau dana darurat.</p>
            </div>
          )}
          {savingsRate < 20 && (
            <div className="flex gap-2.5 p-3 bg-blue-50 rounded-xl border border-blue-100">
              <span className="text-blue-500 text-base shrink-0">i</span>
              <p className="text-sm text-blue-700">Tingkatkan savings rate ke 20%+ untuk keuangan yang lebih kuat. Target tabungan+investasi: {formatRupiah(Math.round(penghasilan * 0.2))}/bln.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
