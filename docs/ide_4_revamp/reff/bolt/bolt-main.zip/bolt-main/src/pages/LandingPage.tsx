import { ShieldCheck, CloudOff, Lock, ChevronRight, ArrowRight, Wallet } from 'lucide-react';

interface LandingPageProps {
  onStart: () => void;
  onDemo: () => void;
}

export default function LandingPage({ onStart, onDemo }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-gray-50 flex flex-col">
      {/* Navbar */}
      <nav className="w-full px-6 py-4 flex items-center justify-between border-b border-gray-100 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center shadow-sm">
            <ShieldCheck className="w-4 h-4 text-white" strokeWidth={2.5} />
          </div>
          <span className="text-xl font-bold text-slate-900 tracking-tight">Cermat</span>
        </div>
        <span className="text-sm text-slate-400 font-medium hidden sm:block">
          Cek Keuangan dalam 10 Menit
        </span>
      </nav>

      {/* Hero */}
      <main className="flex-1 flex flex-col items-center justify-center px-4 py-24">
        {/* Eyebrow tag */}
        <div className="inline-flex items-center gap-1.5 bg-emerald-50 border border-emerald-100 text-emerald-700 text-xs font-semibold px-3 py-1.5 rounded-full mb-6">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Kalkulator Keuangan Pribadi</span>
        </div>

        {/* Headline */}
        <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-900 text-center leading-tight max-w-2xl tracking-tight">
          Aman gak kalau gw KPR,{' '}
          <span className="text-emerald-600">Gadai,</span> atau Cicil?
        </h1>

        {/* Subheadline */}
        <p className="text-lg text-slate-500 mt-5 text-center max-w-lg leading-relaxed">
          Berapa max utang yang aman? Cek keuangan kamu dalam 10 menit — gratis, tanpa simpan data.
        </p>

        {/* Trust Badges */}
        <div className="flex items-center gap-3 mt-8 flex-wrap justify-center">
          <span className="inline-flex items-center gap-1.5 bg-green-50 text-emerald-700 border border-green-100 text-sm font-medium px-4 py-2 rounded-full">
            <Lock className="w-3.5 h-3.5" />
            Tanpa daftar
          </span>
          <span className="inline-flex items-center gap-1.5 bg-green-50 text-emerald-700 border border-green-100 text-sm font-medium px-4 py-2 rounded-full">
            <CloudOff className="w-3.5 h-3.5" />
            Tanpa cloud
          </span>
        </div>

        {/* Action Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mt-14 w-full max-w-4xl">
          {/* Card 1: Primary */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden group">
            <div className="h-1 w-full bg-gradient-to-r from-emerald-500 to-emerald-400 rounded-t-2xl" />
            <div className="p-8">
              <div className="w-12 h-12 bg-emerald-50 rounded-xl flex items-center justify-center mb-5 group-hover:bg-emerald-100 transition-colors">
                <Wallet className="w-6 h-6 text-emerald-600" />
              </div>
              <h2 className="text-xl font-bold text-slate-900 mb-2">Mulai dari Snapshot</h2>
              <p className="text-slate-500 text-sm leading-relaxed mb-7">
                Isi data kamu sendiri (5–10 menit). Dapatkan gambaran lengkap keuangan pribadimu.
              </p>
              <button
                onClick={onStart}
                className="w-full bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-semibold py-3 px-6 rounded-xl flex items-center justify-center gap-2 transition-all duration-200 shadow-sm hover:shadow-emerald-200 hover:shadow-md"
              >
                Mulai
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Card 2: Secondary */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-all duration-300 group">
            <div className="p-8 h-full flex flex-col">
              <div className="w-12 h-12 bg-gray-50 rounded-xl flex items-center justify-center mb-5 group-hover:bg-gray-100 transition-colors">
                <svg
                  className="w-6 h-6 text-slate-500"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M5 3l14 9-14 9V3z" />
                </svg>
              </div>
              <h2 className="text-xl font-bold text-slate-900 mb-2">Coba dengan data contoh</h2>
              <p className="text-slate-500 text-sm leading-relaxed mb-7 flex-1">
                Skip dulu, lihat cara kerjanya dengan contoh data yang sudah terisi.
              </p>
              <button
                onClick={onDemo}
                className="w-full bg-green-50 hover:bg-emerald-50 border border-emerald-200 text-emerald-700 font-semibold py-3 px-6 rounded-xl flex items-center justify-center gap-2 transition-all duration-200"
              >
                Coba
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Feature highlights */}
        <div className="grid grid-cols-3 gap-6 mt-12 max-w-2xl w-full">
          {[
            { label: 'Bebas Biaya', sub: 'Selamanya gratis' },
            { label: 'Real-time', sub: 'Update otomatis' },
            { label: '100% Privat', sub: 'Data di browser' },
          ].map((f) => (
            <div key={f.label} className="text-center">
              <div className="text-sm font-semibold text-slate-700">{f.label}</div>
              <div className="text-xs text-slate-400 mt-0.5">{f.sub}</div>
            </div>
          ))}
        </div>
      </main>

      {/* Footer */}
      <footer className="py-6 px-4 border-t border-gray-100 bg-white">
        <p className="text-center text-xs text-slate-400 flex items-center justify-center gap-1.5">
          <Lock className="w-3 h-3" />
          Cermat. Data diproses secara lokal di browser Anda untuk privasi maksimal.
        </p>
      </footer>
    </div>
  );
}
