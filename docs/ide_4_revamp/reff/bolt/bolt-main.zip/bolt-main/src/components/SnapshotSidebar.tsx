import { TrendingUp, TrendingDown, BarChart2, LineChart, Wallet, AlertTriangle, CheckCircle } from 'lucide-react';
import { FinancialData, calcSummary, formatRupiah } from '../lib/finance';

interface SidebarProps {
  data: FinancialData;
}

export default function SnapshotSidebar({ data }: SidebarProps) {
  const { penghasilan, totalPengeluaran, totalAset, kekayaanBersih, surplus, dsr } = calcSummary(data);

  const dsrColor = dsr === 0 ? 'text-slate-400' : dsr <= 30 ? 'text-emerald-600' : dsr <= 40 ? 'text-amber-500' : 'text-red-500';
  const surplusPositive = surplus >= 0;

  const summaryCards = [
    {
      label: 'Penghasilan',
      value: formatRupiah(penghasilan),
      icon: TrendingUp,
      color: 'text-emerald-600',
      bg: 'bg-emerald-50',
    },
    {
      label: 'Pengeluaran',
      value: formatRupiah(totalPengeluaran),
      icon: TrendingDown,
      color: 'text-red-500',
      bg: 'bg-red-50',
    },
    {
      label: 'Total Aset',
      value: formatRupiah(totalAset),
      icon: LineChart,
      color: 'text-blue-600',
      bg: 'bg-blue-50',
    },
    {
      label: 'Kekayaan Bersih',
      value: formatRupiah(kekayaanBersih),
      icon: BarChart2,
      color: kekayaanBersih >= 0 ? 'text-emerald-600' : 'text-red-500',
      bg: kekayaanBersih >= 0 ? 'bg-emerald-50' : 'bg-red-50',
    },
  ];

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h2 className="text-base font-semibold text-slate-800">Ringkasan Cepat</h2>
        <p className="text-xs text-slate-400 mt-0.5">Diperbarui otomatis saat Anda mengisi</p>
      </div>

      {/* 2x2 Grid */}
      <div className="grid grid-cols-2 gap-3">
        {summaryCards.map((card) => {
          const Icon = card.icon;
          return (
            <div
              key={card.label}
              className="bg-white rounded-xl border border-gray-100 shadow-sm p-3.5 flex flex-col gap-2"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-500 font-medium">{card.label}</span>
                <div className={`w-6 h-6 ${card.bg} rounded-lg flex items-center justify-center`}>
                  <Icon className={`w-3.5 h-3.5 ${card.color}`} />
                </div>
              </div>
              <span className="text-sm font-bold text-slate-800 leading-tight break-all">
                {card.value}
              </span>
            </div>
          );
        })}
      </div>

      {/* Surplus Bar */}
      <div className={`rounded-xl p-4 border ${surplusPositive ? 'bg-emerald-50 border-emerald-100' : 'bg-red-50 border-red-100'}`}>
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-1.5">
            <Wallet className={`w-4 h-4 ${surplusPositive ? 'text-emerald-600' : 'text-red-500'}`} />
            <span className="text-xs font-semibold text-slate-600">Surplus Bulanan</span>
          </div>
          {surplusPositive ? (
            <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
          ) : (
            <AlertTriangle className="w-3.5 h-3.5 text-red-500" />
          )}
        </div>
        <div className={`text-2xl font-extrabold ${surplusPositive ? 'text-emerald-700' : 'text-red-600'} mt-1`}>
          {surplusPositive ? '+' : ''}{formatRupiah(surplus)}
        </div>
        <p className="text-xs text-slate-500 mt-1">
          {surplusPositive ? 'Keuangan Anda sehat!' : 'Pengeluaran melebihi pemasukan'}
        </p>
      </div>

      {/* DSR */}
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-4">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-semibold text-slate-600">Debt Service Ratio</span>
          <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
            dsr === 0 ? 'bg-gray-100 text-slate-500' :
            dsr <= 30 ? 'bg-emerald-100 text-emerald-700' :
            dsr <= 40 ? 'bg-amber-100 text-amber-700' :
            'bg-red-100 text-red-700'
          }`}>
            {dsr === 0 ? '-' : `${dsr.toFixed(1)}%`}
          </span>
        </div>
        <div className="w-full bg-gray-100 rounded-full h-2 overflow-hidden">
          <div
            className={`h-2 rounded-full transition-all duration-500 ${
              dsr <= 30 ? 'bg-emerald-500' : dsr <= 40 ? 'bg-amber-400' : 'bg-red-500'
            }`}
            style={{ width: `${Math.min(dsr, 100)}%` }}
          />
        </div>
        <div className="flex justify-between mt-2">
          <span className="text-xs text-slate-400">0%</span>
          <span className={`text-xs font-semibold ${dsrColor}`}>{dsr === 0 ? 'Isi data cicilan' : dsr <= 30 ? 'Aman (< 30%)' : dsr <= 40 ? 'Waspada (30–40%)' : 'Berisiko (> 40%)'}</span>
          <span className="text-xs text-slate-400">100%</span>
        </div>
      </div>

      {/* Privacy note */}
      <div className="flex items-start gap-2 bg-slate-50 rounded-xl border border-slate-100 p-3">
        <svg className="w-4 h-4 text-slate-400 mt-0.5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
          <path d="M7 11V7a5 5 0 0 1 10 0v4" />
        </svg>
        <p className="text-xs text-slate-400 leading-relaxed">
          Data Anda diproses lokal di browser. Tidak ada data yang dikirim ke server kami.
        </p>
      </div>
    </div>
  );
}
