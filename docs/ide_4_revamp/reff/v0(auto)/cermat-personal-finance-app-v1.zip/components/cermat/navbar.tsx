"use client"

import Link from "next/link"
import { ShieldCheck } from "lucide-react"

export function Navbar() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/60 bg-white/90 backdrop-blur-sm">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4">
        <Link href="/" className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
            <ShieldCheck className="h-4 w-4 text-primary-foreground" />
          </div>
          <span className="text-xl font-bold tracking-tight text-slate-900">Cermat</span>
        </Link>
        <span className="hidden text-sm text-slate-500 sm:block">
          Cek Keuangan dalam 10 Menit
        </span>
      </div>
    </header>
  )
}
