"use client"

import Link from "next/link"
import { Lock, CloudOff, ChevronRight, ArrowRight, FileText, Play } from "lucide-react"
import { Button } from "@/components/ui/button"

export function HeroSection() {
  return (
    <section className="mx-auto max-w-5xl px-6 py-24 text-center">
      {/* Trust Badges */}
      <div className="mb-10 flex flex-wrap items-center justify-center gap-3">
        <span className="inline-flex items-center gap-1.5 rounded-full border border-green-100 bg-green-50 px-4 py-1.5 text-sm font-medium text-emerald-700">
          <Lock className="h-3.5 w-3.5" />
          Tanpa daftar
        </span>
        <span className="inline-flex items-center gap-1.5 rounded-full border border-green-100 bg-green-50 px-4 py-1.5 text-sm font-medium text-emerald-700">
          <CloudOff className="h-3.5 w-3.5" />
          Tanpa cloud
        </span>
      </div>

      {/* Headline */}
      <h1 className="text-balance text-4xl font-bold leading-tight tracking-tight text-slate-900 sm:text-5xl lg:text-6xl">
        Aman gak kalau gw{" "}
        <span className="text-primary">KPR</span>,{" "}
        <span className="text-primary">Gadai</span>, atau{" "}
        <span className="text-primary">Cicil</span>?
      </h1>

      {/* Sub-headline */}
      <p className="mx-auto mt-6 max-w-xl text-lg leading-relaxed text-slate-600">
        Berapa max utang yang aman? Cek keuangan kamu dalam 10 menit.
      </p>

      {/* CTA Cards Grid */}
      <div className="mx-auto mt-14 grid max-w-3xl gap-5 sm:grid-cols-2">
        {/* Card 1 – Primary */}
        <div className="group relative flex flex-col gap-5 overflow-hidden rounded-2xl border border-border bg-white p-6 shadow-sm transition-all hover:shadow-md">
          {/* green top accent bar */}
          <div className="absolute inset-x-0 top-0 h-1 rounded-t-2xl bg-primary" />
          <div className="flex items-start gap-4">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-green-50">
              <FileText className="h-6 w-6 text-primary" />
            </div>
            <div className="text-left">
              <h2 className="text-xl font-bold text-slate-900">Mulai dari Snapshot</h2>
              <p className="mt-1 text-sm leading-relaxed text-slate-500">
                Isi data kamu sendiri (5–10 menit).
              </p>
            </div>
          </div>
          <Link href="/snapshot" className="mt-auto">
            <Button className="w-full gap-2 bg-primary text-primary-foreground hover:bg-primary/90">
              Mulai
              <ChevronRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>

        {/* Card 2 – Secondary */}
        <div className="group flex flex-col gap-5 rounded-2xl border border-border bg-white p-6 shadow-sm transition-all hover:shadow-md">
          <div className="flex items-start gap-4">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-slate-50">
              <Play className="h-6 w-6 text-slate-500" />
            </div>
            <div className="text-left">
              <h2 className="text-xl font-bold text-slate-900">Coba dengan data contoh</h2>
              <p className="mt-1 text-sm leading-relaxed text-slate-500">
                Skip dulu, lihat tools-nya.
              </p>
            </div>
          </div>
          <Link href="/snapshot?demo=true" className="mt-auto">
            <Button
              variant="outline"
              className="w-full gap-2 border-green-100 bg-green-50 text-emerald-700 hover:bg-green-100 hover:text-emerald-800"
            >
              Coba
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
