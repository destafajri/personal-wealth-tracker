"use client"

import { useState } from "react"
import { Info } from "lucide-react"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"

interface CurrencyInputProps {
  label: string
  sublabel?: string
  tooltip?: string
  placeholder?: string
  value: number
  onChange: (value: number) => void
}

function formatDisplay(val: number): string {
  if (!val) return ""
  return val.toLocaleString("id-ID")
}

export function CurrencyInput({
  label,
  sublabel,
  tooltip,
  placeholder = "0",
  value,
  onChange,
}: CurrencyInputProps) {
  const [raw, setRaw] = useState(value ? formatDisplay(value) : "")

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const stripped = e.target.value.replace(/\./g, "").replace(/[^0-9]/g, "")
    const num = parseInt(stripped, 10) || 0
    setRaw(stripped ? num.toLocaleString("id-ID") : "")
    onChange(num)
  }

  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-center gap-1.5">
        <label className="text-sm font-medium text-slate-700">{label}</label>
        {tooltip && (
          <TooltipProvider delayDuration={200}>
            <Tooltip>
              <TooltipTrigger asChild>
                <button type="button" className="text-slate-400 hover:text-slate-600">
                  <Info className="h-3.5 w-3.5" />
                  <span className="sr-only">Info: {label}</span>
                </button>
              </TooltipTrigger>
              <TooltipContent side="right" className="max-w-[200px] text-xs">
                {tooltip}
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}
      </div>
      {sublabel && <p className="text-xs text-slate-400">{sublabel}</p>}
      <div className="relative flex items-center overflow-hidden rounded-xl border border-input bg-white shadow-sm ring-0 transition-all focus-within:border-primary focus-within:ring-2 focus-within:ring-primary/20">
        <span className="border-r border-input bg-muted px-3 py-2.5 text-sm font-medium text-slate-500 select-none">
          Rp
        </span>
        <input
          type="text"
          inputMode="numeric"
          value={raw}
          onChange={handleChange}
          placeholder={placeholder}
          className="flex-1 bg-transparent px-3 py-2.5 text-sm font-medium text-slate-900 outline-none placeholder:text-slate-300"
        />
      </div>
    </div>
  )
}
