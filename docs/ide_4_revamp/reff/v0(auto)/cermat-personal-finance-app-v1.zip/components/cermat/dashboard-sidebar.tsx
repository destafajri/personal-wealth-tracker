"use client"

import { ArrowUp, ArrowDown, LineChart, BarChart2, Wallet } from "lucide-react"

interface FinancialData {
  penghasilan: number
  pengeluaran: number
  totalAset: number
  kekayaanBersih: number
}

interface DashboardSidebarProps {
  data: FinancialData
}

function formatRupiah(value: number): string {
  if (value === 0) return "Rp 0"
  const abs = Math.abs(value)
  let formatted: string
  if (abs >= 1_000_000_000) {
    formatted = (abs / 1_000_000_000).toFixed(1).replace(".", ",") + " M"
  } else if (abs >= 1_000_000) {
    formatted =
      "Rp " +
      Math.round(abs / 1_000)
        .toString()
        .replace(/\B(?=(\d{3})+(?!\d))/g, ".")
        .slice(0, -3) +
      " Jt"
    // fallback: show full
    formatted = "Rp " + abs.toLocaleString("id-ID")
  } else {
    formatted = "Rp " + abs.toLocaleString("id-ID")
  }
  return (value < 0 ? "-" : "") + "Rp " + abs.toLocaleString("id-ID")
}

const metricCards = [
  {
    key: "penghasilan" as keyof FinancialData,
    label: "Penghasilan",
    icon: ArrowUp,
    colorClass: "text-emerald-600",
    bgClass: "bg-emerald-50",
    borderClass: "border-emerald-100",
  },
  {
    key: "pengeluaran" as keyof FinancialData,
    label: "Pengeluaran",
    icon: ArrowDown,
    colorClass: "text-rose-500",
    bgClass: "bg-rose-50",
    borderClass: "border-rose-100",
  },
  {
    key: "totalAset" as keyof FinancialData,
    label: "Total Aset",
    icon: LineChart,
    colorClass: "text-blue-600",
    bgClass: "bg-blue-50",
    borderClass: "border-blue-100",
  },
  {
    key: "kekayaanBersih" as keyof FinancialData,
    label: "Kekayaan Bersih",
    icon: BarChart2,
    colorClass: "text-emerald-600",
    bgClass: "bg-emerald-50",
    borderClass: "border-emerald-100",
  },
]

export function DashboardSidebar({ data }: DashboardSidebarProps) {
  const surplus = data.penghasilan - data.pengeluaran
  const isPositive = surplus >= 0

  return (
    <aside className="flex flex-col gap-4">
      {/* Title */}
      <div>
        <h2 className="text-base font-semibold text-slate-800">Ringkasan Cepat</h2>
        <p className="mt-0.5 text-xs text-slate-400">Diperbarui otomatis saat Anda mengisi</p>
      </div>

      {/* 2x2 metric grid */}
      <div className="grid grid-cols-2 gap-3">
        {metricCards.map(({ key, label, icon: Icon, colorClass, bgClass, borderClass }) => (
          <div
            key={key}
            className={`flex flex-col gap-2 rounded-xl border ${borderClass} bg-white p-3 shadow-sm`}
          >
            <div className="flex items-center gap-1.5">
              <div className={`flex h-6 w-6 items-center justify-center rounded-md ${bgClass}`}>
                <Icon className={`h-3.5 w-3.5 ${colorClass}`} />
              </div>
              <span className="text-xs font-medium text-slate-500">{label}</span>
            </div>
            <p className={`text-sm font-bold leading-tight ${colorClass}`}>
              {formatRupiah(data[key])}
            </p>
          </div>
        ))}
      </div>

      {/* Surplus Highlight */}
      <div
        className={`rounded-2xl border p-4 ${
          isPositive
            ? "border-emerald-100 bg-emerald-50"
            : "border-rose-100 bg-rose-50"
        }`}
      >
        <div className="flex items-center gap-2">
          <div
            className={`flex h-8 w-8 items-center justify-center rounded-xl ${
              isPositive ? "bg-emerald-100" : "bg-rose-100"
            }`}
          >
            <Wallet
              className={`h-4 w-4 ${isPositive ? "text-emerald-600" : "text-rose-500"}`}
            />
          </div>
          <span className="text-sm font-medium text-slate-600">Surplus Bulanan</span>
        </div>
        <p
          className={`mt-3 text-2xl font-bold tracking-tight ${
            isPositive ? "text-emerald-700" : "text-rose-600"
          }`}
        >
          {isPositive ? "+" : ""}
          {formatRupiah(surplus)}
        </p>
        <p className="mt-1 text-xs text-slate-500">
          {isPositive
            ? "Keuangan Anda dalam kondisi sehat."
            : "Pengeluaran melebihi penghasilan."}
        </p>
      </div>

      {/* Debt Ratio Card */}
      <div className="rounded-xl border border-border bg-white p-4 shadow-sm">
        <p className="text-xs font-medium text-slate-500">Rasio Utang Aman (maks.)</p>
        <p className="mt-1 text-xl font-bold text-slate-900">
          {formatRupiah(surplus * 0.3)}
          <span className="ml-1 text-xs font-normal text-slate-400">/bln</span>
        </p>
        <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-slate-100">
          <div
            className="h-full rounded-full bg-primary transition-all duration-500"
            style={{ width: `${Math.min((data.pengeluaran / Math.max(data.penghasilan, 1)) * 100, 100)}%` }}
          />
        </div>
        <p className="mt-1.5 text-xs text-slate-400">
          Cicilan &le; 30% dari penghasilan
        </p>
      </div>
    </aside>
  )
}
