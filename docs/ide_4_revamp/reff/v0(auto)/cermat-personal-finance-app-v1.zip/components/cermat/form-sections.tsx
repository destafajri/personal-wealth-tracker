"use client"

import { useState } from "react"
import {
  TrendingUp,
  ShoppingCart,
  PiggyBank,
  BarChart2,
  Home,
  CreditCard,
  CheckCircle2,
  Wallet,
  ChevronDown,
} from "lucide-react"
import { CurrencyInput } from "./currency-input"
import { cn } from "@/lib/utils"

interface SectionData {
  [key: string]: number
}

interface SnapshotFormData {
  penghasilan: SectionData
  pengeluaran: SectionData
  tabungan: SectionData
  investasi: SectionData
  aset: SectionData
  utang: SectionData
}

interface FormSectionsProps {
  onDataChange: (totals: {
    penghasilan: number
    pengeluaran: number
    totalAset: number
    kekayaanBersih: number
  }) => void
}

const sections = [
  {
    id: "penghasilan",
    title: "Penghasilan Bulanan",
    subtitle: "Masukkan semua sumber pendapatan Anda per bulan",
    icon: TrendingUp,
    color: "text-emerald-600",
    bg: "bg-emerald-50",
    border: "border-emerald-100",
    fields: [
      { key: "gaji", label: "Gaji Pokok", sublabel: "Gaji utama dari pekerjaan", placeholder: "15.000.000", tooltip: "Gaji bersih setelah pajak dan potongan" },
      { key: "sampingan", label: "Pendapatan Sampingan", sublabel: "Freelance, bisnis sampingan", placeholder: "3.000.000", tooltip: "Semua pendapatan di luar gaji utama" },
      { key: "lainnya", label: "Pendapatan Lainnya", sublabel: "Dividen, sewa, dll", placeholder: "1.000.000", tooltip: "Dividen, hasil sewa, royalti, dll" },
    ],
  },
  {
    id: "pengeluaran",
    title: "Pengeluaran Bulanan",
    subtitle: "Hitung semua biaya rutin dan variabel Anda",
    icon: ShoppingCart,
    color: "text-rose-500",
    bg: "bg-rose-50",
    border: "border-rose-100",
    fields: [
      { key: "makan", label: "Makan & Groceries", sublabel: "Biaya makan harian dan belanja", placeholder: "3.000.000", tooltip: "Total pengeluaran untuk makanan per bulan" },
      { key: "transport", label: "Transportasi", sublabel: "Bensin, parkir, ojek online", placeholder: "1.500.000", tooltip: "Semua biaya perjalanan harian" },
      { key: "sewa", label: "Sewa / Kos / KPR", sublabel: "Biaya tempat tinggal", placeholder: "2.500.000", tooltip: "Cicilan KPR atau biaya sewa bulanan" },
      { key: "utilitas", label: "Utilitas & Tagihan", sublabel: "Listrik, air, internet, telepon", placeholder: "800.000", tooltip: "PLN, PDAM, paket data, dll" },
      { key: "hiburan", label: "Hiburan & Lifestyle", sublabel: "Nongkrong, streaming, hobi", placeholder: "1.000.000", tooltip: "Pengeluaran tidak wajib tapi rutin" },
      { key: "lainnya", label: "Lainnya", sublabel: "Biaya tidak terduga, dll", placeholder: "500.000" },
    ],
  },
  {
    id: "tabungan",
    title: "Tabungan",
    subtitle: "Berapa yang Anda sisihkan tiap bulan?",
    icon: PiggyBank,
    color: "text-sky-600",
    bg: "bg-sky-50",
    border: "border-sky-100",
    fields: [
      { key: "darurat", label: "Dana Darurat", sublabel: "Tabungan untuk keadaan darurat", placeholder: "2.000.000", tooltip: "Target ideal: 3–6x pengeluaran bulanan" },
      { key: "tujuan", label: "Tabungan Tujuan", sublabel: "Liburan, beli barang, dll", placeholder: "1.000.000" },
      { key: "pensiun", label: "Dana Pensiun", sublabel: "BPJS TK, dana pensiun pribadi", placeholder: "500.000" },
    ],
  },
  {
    id: "investasi",
    title: "Investasi",
    subtitle: "Portofolio investasi aktif Anda saat ini",
    icon: BarChart2,
    color: "text-violet-600",
    bg: "bg-violet-50",
    border: "border-violet-100",
    fields: [
      { key: "saham", label: "Saham / Reksa Dana", sublabel: "Nilai portofolio saat ini", placeholder: "50.000.000", tooltip: "Nilai pasar saat ini, bukan modal awal" },
      { key: "obligasi", label: "Obligasi / Sukuk", sublabel: "Surat berharga negara, dll", placeholder: "10.000.000" },
      { key: "kripto", label: "Kripto", sublabel: "Bitcoin, altcoin, dll", placeholder: "5.000.000" },
      { key: "lainnya", label: "Investasi Lainnya", sublabel: "P2P lending, emas digital", placeholder: "0" },
    ],
  },
  {
    id: "aset",
    title: "Aset",
    subtitle: "Semua aset fisik dan finansial yang Anda miliki",
    icon: Home,
    color: "text-amber-600",
    bg: "bg-amber-50",
    border: "border-amber-100",
    fields: [
      { key: "properti", label: "Properti", sublabel: "Rumah, tanah, ruko (nilai pasar)", placeholder: "500.000.000", tooltip: "Estimasi nilai jual saat ini" },
      { key: "kendaraan", label: "Kendaraan", sublabel: "Motor, mobil (nilai pasar)", placeholder: "150.000.000" },
      { key: "emas", label: "Emas Fisik", sublabel: "Perhiasan, logam mulia", placeholder: "20.000.000" },
      { key: "lainnya", label: "Aset Lainnya", sublabel: "Barang berharga lainnya", placeholder: "0" },
    ],
  },
  {
    id: "utang",
    title: "Utang",
    subtitle: "Total kewajiban finansial Anda saat ini",
    icon: CreditCard,
    color: "text-red-600",
    bg: "bg-red-50",
    border: "border-red-100",
    fields: [
      { key: "kpr", label: "Sisa KPR", sublabel: "Sisa pokok hutang KPR", placeholder: "400.000.000", tooltip: "Sisa utang KPR yang belum lunas" },
      { key: "kendaraan", label: "Cicilan Kendaraan", sublabel: "Sisa kredit motor/mobil", placeholder: "50.000.000" },
      { key: "kartuKredit", label: "Kartu Kredit", sublabel: "Total tagihan belum lunas", placeholder: "5.000.000", tooltip: "Gunakan saldo outstanding, bukan limit" },
      { key: "pinjaman", label: "Pinjaman Lainnya", sublabel: "KTA, P2P, hutang pribadi", placeholder: "0" },
    ],
  },
]

function sumSection(data: SectionData): number {
  return Object.values(data).reduce((a, b) => a + b, 0)
}

export function FormSections({ onDataChange }: FormSectionsProps) {
  const [formData, setFormData] = useState<SnapshotFormData>({
    penghasilan: {},
    pengeluaran: {},
    tabungan: {},
    investasi: {},
    aset: {},
    utang: {},
  })

  const [openSections, setOpenSections] = useState<Record<string, boolean>>(
    Object.fromEntries(sections.map((s, i) => [s.id, i === 0]))
  )

  const [completedSections, setCompletedSections] = useState<Record<string, boolean>>({})

  const updateField = (sectionId: keyof SnapshotFormData, field: string, value: number) => {
    const updated = {
      ...formData,
      [sectionId]: { ...formData[sectionId], [field]: value },
    }
    setFormData(updated)

    const penghasilan = sumSection(updated.penghasilan)
    const pengeluaran = sumSection(updated.pengeluaran)
    const investasiTotal = sumSection(updated.investasi)
    const asetTotal = sumSection(updated.aset)
    const utangTotal = sumSection(updated.utang)
    const totalAset = asetTotal + investasiTotal
    const kekayaanBersih = totalAset - utangTotal

    onDataChange({ penghasilan, pengeluaran, totalAset, kekayaanBersih })
  }

  const toggleSection = (id: string) => {
    setOpenSections((prev) => ({ ...prev, [id]: !prev[id] }))
  }

  const markComplete = (id: string, nextId?: string) => {
    setCompletedSections((prev) => ({ ...prev, [id]: true }))
    setOpenSections((prev) => ({
      ...prev,
      [id]: false,
      ...(nextId ? { [nextId]: true } : {}),
    }))
    if (nextId) {
      setTimeout(() => {
        document.getElementById(`section-${nextId}`)?.scrollIntoView({ behavior: "smooth", block: "start" })
      }, 100)
    }
  }

  return (
    <div className="relative flex flex-col gap-0">
      {/* Vertical timeline line */}
      <div className="absolute left-5 top-8 bottom-8 w-px bg-border hidden sm:block" />

      {sections.map((section, index) => {
        const Icon = section.icon
        const isOpen = openSections[section.id]
        const isCompleted = completedSections[section.id]
        const sectionTotal = sumSection(formData[section.id as keyof SnapshotFormData])
        const nextSection = sections[index + 1]

        return (
          <div
            key={section.id}
            id={`section-${section.id}`}
            className="relative scroll-mt-6 pb-4"
          >
            {/* Timeline dot */}
            <div
              className={cn(
                "absolute left-3.5 top-5 z-10 h-3 w-3 rounded-full border-2 hidden sm:block",
                isCompleted
                  ? "border-primary bg-primary"
                  : isOpen
                  ? "border-primary bg-white"
                  : "border-slate-300 bg-white"
              )}
            />

            <div className="sm:ml-12">
              {/* Section Header (Accordion toggle) */}
              <button
                type="button"
                onClick={() => toggleSection(section.id)}
                className={cn(
                  "flex w-full items-center justify-between rounded-2xl border p-4 text-left transition-all",
                  isOpen
                    ? `${section.border} ${section.bg}`
                    : "border-border bg-white hover:bg-muted/50"
                )}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={cn(
                      "flex h-10 w-10 shrink-0 items-center justify-center rounded-xl",
                      isCompleted ? "bg-primary" : section.bg
                    )}
                  >
                    {isCompleted ? (
                      <CheckCircle2 className="h-5 w-5 text-white" />
                    ) : (
                      <Icon className={cn("h-5 w-5", section.color)} />
                    )}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-800">{section.title}</p>
                    {sectionTotal > 0 && !isOpen && (
                      <p className="text-xs text-slate-400">
                        Total: Rp {sectionTotal.toLocaleString("id-ID")}
                      </p>
                    )}
                  </div>
                </div>
                <ChevronDown
                  className={cn(
                    "h-4 w-4 text-slate-400 transition-transform duration-200",
                    isOpen && "rotate-180"
                  )}
                />
              </button>

              {/* Section Body */}
              {isOpen && (
                <div className="mt-2 rounded-2xl border border-border bg-white p-5 shadow-sm">
                  {/* Header */}
                  <div className="mb-5 border-b border-border pb-4">
                    <h3 className="text-lg font-bold text-slate-900">{section.title}</h3>
                    <p className="mt-1 text-sm text-slate-500">{section.subtitle}</p>
                  </div>

                  {/* Input Fields */}
                  <div className="grid gap-4 sm:grid-cols-2">
                    {section.fields.map((field) => (
                      <CurrencyInput
                        key={field.key}
                        label={field.label}
                        sublabel={field.sublabel}
                        placeholder={field.placeholder}
                        tooltip={field.tooltip}
                        value={formData[section.id as keyof SnapshotFormData][field.key] || 0}
                        onChange={(val) =>
                          updateField(section.id as keyof SnapshotFormData, field.key, val)
                        }
                      />
                    ))}
                  </div>

                  {/* Section Subtotal */}
                  {sectionTotal > 0 && (
                    <div
                      className={cn(
                        "mt-5 flex items-center gap-3 rounded-xl border p-3",
                        section.border,
                        section.bg
                      )}
                    >
                      <Wallet className={cn("h-4 w-4 shrink-0", section.color)} />
                      <div>
                        <p className="text-xs text-slate-500">Total {section.title}</p>
                        <p className={cn("text-base font-bold", section.color)}>
                          Rp {sectionTotal.toLocaleString("id-ID")}
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Completion CTA */}
                  <div className="mt-5 flex items-center justify-between gap-3">
                    {index > 0 && (
                      <button
                        type="button"
                        onClick={() => {
                          const prev = sections[index - 1]
                          setOpenSections((o) => ({ ...o, [section.id]: false, [prev.id]: true }))
                        }}
                        className="rounded-xl border border-border px-4 py-2 text-sm font-medium text-slate-600 hover:bg-muted/60 transition-colors"
                      >
                        Sebelumnya
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => markComplete(section.id, nextSection?.id)}
                      className="ml-auto flex items-center gap-2 rounded-xl bg-primary px-5 py-2 text-sm font-semibold text-white hover:bg-primary/90 transition-colors"
                    >
                      {nextSection ? "Simpan & Lanjutkan" : "Simpan & Lihat Hasil"}
                      <CheckCircle2 className="h-4 w-4" />
                    </button>
                  </div>

                  {/* Privacy note */}
                  <p className="mt-3 flex items-center gap-1 text-xs text-slate-400">
                    <span>🔒</span>
                    Privasi Anda terjaga. Data disimpan lokal di browser Anda, tidak dikirim ke server.
                  </p>
                </div>
              )}
            </div>
          </div>
        )
      })}
    </div>
  )
}
