import { Lock } from "lucide-react"

export function LandingFooter() {
  return (
    <footer className="border-t border-border/60 bg-white/60 py-8 text-center">
      <p className="mx-auto flex max-w-sm items-center justify-center gap-1.5 text-sm text-slate-400">
        <Lock className="h-3.5 w-3.5 shrink-0" />
        Cermat. Data diproses secara lokal di browser Anda untuk privasi maksimal.
      </p>
    </footer>
  )
}
