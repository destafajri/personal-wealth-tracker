import { Navbar } from "@/components/cermat/navbar"
import { HeroSection } from "@/components/cermat/hero-section"
import { LandingFooter } from "@/components/cermat/landing-footer"

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-white to-gray-50">
      <Navbar />
      <main className="flex-1">
        <HeroSection />
      </main>
      <LandingFooter />
    </div>
  )
}
