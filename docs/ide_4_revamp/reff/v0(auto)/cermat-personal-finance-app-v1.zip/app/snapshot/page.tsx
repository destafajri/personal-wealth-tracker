"use client"

import { useState } from "react"
import Link from "next/link"
import { ShieldCheck, Lock, ArrowLeft } from "lucide-react"
import { DashboardSidebar } from "@/components/cermat/dashboard-sidebar"
import { FormSections } from "@/components/cermat/form-sections"

interface FinancialSummary {
  penghasilan: number
  pengeluaran: number
  totalAset: number
  kekayaanBersih: number
}

const DEMO_DATA: FinancialSummary = {
  penghasilan: 18_000_000,
  pengeluaran: 9_500_000,
  totalAset: 320_000_000,
  kekayaanBersih: 270_000_000,
}

export default function SnapshotPage() {
  const [summary, setSummary] = useState<FinancialSummary>({
    penghasilan: 0,
    pengeluaran: 0,
    totalAset: 0,
    kekayaanBersih: 0,
  })

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-gray-50">
      {/* Top Header */}
      <header className="sticky top-0 z-50 border-b border-border/60 bg-white/90 backdrop-blur-sm">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-3.5">
          <div className="flex items-center gap-3">
            <Link
              href="/"
              className="flex items-center gap-1 rounded-lg p-1 text-slate-400 hover:bg-muted hover:text-slate-600 transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              <span className="sr-only">Kembali</span>
            </Link>
            <div className="h-5 w-px bg-border" />
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary">
                <ShieldCheck className="h-3.5 w-3.5 text-white" />
              </div>
              <div>
                <span className="text-base font-bold text-slate-900">Cermat</span>
                <span className="ml-1.5 hidden text-xs text-slate-400 sm:inline">
                  Kalkulator Keuangan
                </span>
              </div>
            </Link>
          </div>

          <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-slate-50 px-3 py-1 text-xs font-medium text-slate-500">
            <Lock className="h-3 w-3" />
            Gratis &bull; Tanpa Login
          </span>
        </div>
      </header>

      {/* Split-Screen Layout */}
      <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
        <div className="flex flex-col gap-8 lg:flex-row lg:items-start lg:gap-8">

          {/* LEFT: Sticky Dashboard */}
          <div className="w-full lg:sticky lg:top-20 lg:w-80 lg:shrink-0">
            <DashboardSidebar data={summary} />
          </div>

          {/* RIGHT: Scrollable Form */}
          <div className="flex-1 min-w-0">
            <div className="mb-6">
              <h1 className="text-2xl font-bold text-slate-900">Financial Snapshot</h1>
              <p className="mt-1 text-sm text-slate-500">
                Isi setiap bagian untuk mendapatkan gambaran lengkap kondisi keuangan Anda.
              </p>
            </div>

            {/* Progress dots */}
            <div className="mb-8 flex items-center gap-1.5">
              {["Penghasilan", "Pengeluaran", "Tabungan", "Investasi", "Aset", "Utang"].map(
                (label, i) => (
                  <div key={label} className="flex items-center gap-1.5">
                    <div
                      className="h-2 w-2 rounded-full bg-primary/30"
                      title={label}
                    />
                    {i < 5 && <div className="h-px w-4 bg-border" />}
                  </div>
                )
              )}
              <span className="ml-2 text-xs text-slate-400">6 bagian</span>
            </div>

            <FormSections onDataChange={setSummary} />
          </div>
        </div>
      </div>

      {/* Bottom privacy bar */}
      <div className="mt-8 border-t border-border/60 bg-white/60 py-5 text-center">
        <p className="mx-auto flex max-w-sm items-center justify-center gap-1.5 text-xs text-slate-400">
          <Lock className="h-3 w-3 shrink-0" />
          Data diproses sepenuhnya di browser Anda. Tidak ada yang dikirim ke server kami.
        </p>
      </div>
    </div>
  )
}
